package prktikum.Beans;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sql.PostgreSQLAccess;

	public class frisurbean {
		
		 String styleselecteted ="you can take it from portfolio";
		 ArrayList<Termin> terminen=new ArrayList<Termin>();
		// Appointment
		 String name ;
		 String emailApp ;
		 String email="Your Email" ;
		 String date ;
		 String hour ;
		 String phone ;
		 String subject;
		 String message ;
		 boolean admin ;
		 boolean modif ;
		 int id;


	    private static final String DB_URL = "jdbc:postgresql://143.93.200.243:5435/BWUEBDB";
	    private static final String DB_USER = "user1";
	    private static final String DB_PASSWORD = "pgusers";
	    
	    public static void main(String[] args) {
			frisurbean fb =new frisurbean();
			fb.getFrisuren();
		}
	    boolean login=true;
	    public boolean isLogin() {
			return login;
		}
	    public void setLogin(boolean login) {
			this.login = login;
		}
	     
	    /**
		 * @return the styleselecteted
		 */
		public String getStyleselecteted() {
			return styleselecteted;
		}
		/**
		 * @param styleselecteted the styleselecteted to set
		 */
		public void setStyleselecteted(String styleselecteted) {
			this.styleselecteted = styleselecteted;
			this.subject=styleselecteted;
			System.out.println(subject+"<-- bean--> " +styleselecteted);
		}
		public List<Frisur> getFrisuren(){
	        List<Frisur> frisurenList = new ArrayList<>();
	        try {
	            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	        	

	            String query = "SELECT style, description, preis FROM bwi520_634753.frisurs";
	            PreparedStatement preparedStatement = connection.prepareStatement(query);
	            ResultSet resultSet = preparedStatement.executeQuery();
	            

	            while (resultSet.next()) {
	                Frisur frisur = new Frisur();
	                frisur.setImageFilename(resultSet.getString("style")+".jpeg");
	                frisur.setStyle(resultSet.getString("style"));
	                frisur.setDescription(resultSet.getString("description"));
	                frisur.setPreis(resultSet.getDouble("preis"));
	                frisurenList.add(frisur);
	                System.out.println(frisur.toString());
	            }

	            resultSet.close();
	            preparedStatement.close();
	            connection.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return frisurenList;
	    }
		public void insertTermine(){
			
			try {
				Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
				
				
				String query = "INSERT INTO bwi520_634753.termine (\"name\", emailapp, \"date\", \"hour\", phone, subject, message) VALUES('"+ getName()+"', '"+getEmail()+"', '"+getDate()+"', '"+getHour()+"', '"+getPhone()+"', '"+getSubject()+"', '"+getMessage()+"');	";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				
				preparedStatement.executeUpdate();
				System.out.println("termin inserted");
				getTermine();
				preparedStatement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		public void deletTermine(){
			
			try {
				Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
				
				
				String sql = "DELETE FROM bwi520_634753.termine WHERE id='"+getId()+"';";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.executeUpdate();
				System.out.println("termin deleted");
				preparedStatement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		public void updatTermine(){
			
			try {
				Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
				
				
				String sql = "UPDATE bwi520_634753.termine SET \"name\"='"+getName()+"', \"date\"='"+getDate()+"', \"hour\"='"+getHour()+"', phone='"+getPhone()+"', subject='"+getStyleselecteted()+"', message='"+getMessage()+"' WHERE id='"+getId()+"';";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.executeUpdate();
				System.out.println("termin Updated");
				preparedStatement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
			public void getTermine(){
			terminen.clear();
			String query;
			System.out.println("ich bin ein Admin -->"+isAdmin() +"  mit der email "+email);
			if (isAdmin()) {
				   query = "SELECT id, \"name\", emailapp, \"date\", \"hour\", phone, subject, message FROM bwi520_634753.termine;";

			}else {
			   query = "SELECT id, \"name\", emailapp, \"date\", \"hour\", phone, subject, message FROM bwi520_634753.termine where emailapp ='"+getEmail()+"';";
			}
			try {
				Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
				
				  PreparedStatement preparedStatement = connection.prepareStatement(query);
		            ResultSet resultSet = preparedStatement.executeQuery();
		            
		            while (resultSet.next()) {
		            	
		                int id = resultSet.getInt("id");
		                String name = resultSet.getString("name");
		                String emailapp = resultSet.getString("emailapp");
		                String date = resultSet.getString("date");
		                String hour = resultSet.getString("hour");
		                String phone = resultSet.getString("phone");
		                String subject = resultSet.getString("subject");
		                String message = resultSet.getString("message");
		             terminen.add(new Termin(id, name, emailapp, date, hour, phone, subject, message));               
		            }
		           // htmlBuilder.append("</tbody>");
		            resultSet.close();
		            preparedStatement.close();
		            connection.close();
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
			
		}
		public String getTermineForHtml(){
			getTermine();
			if (modif) {
				Termin inexed = null;
				for (Termin termin : terminen) {
					if (termin.getId()==this.getId()) {
						inexed=termin;
						if (getStyleselecteted().equals("you can take it from portfolio")) {
							setStyleselecteted(inexed.getSubject());
						}
						
					}
				} 
				String html=""
						+ "<form id=\"contact-form\" class=\"form\" action=\"appointmentAppl.jsp\" id=\"modif\" method=\"get\">\r\n"
						+ "							\r\n"
						+ "						<br> <br> <br>\r\n"
						+ "						\r\n"
						+ "						    <table  id=\"modif\">\r\n"
						+ "						    		<tr> <th colspan=\"2\"> <h1>Modifier Appointment</h1>  </th></tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Name:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"name\" value=\""+inexed.getName()+"\" id=\"name\" class=\"form-control\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">E-Mail:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"email\"  id=\"email\" class=\"form-control\" value=\""+getEmail()+"\" disabled=\"disabled\" title=\"can't be modifif\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Date:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"date\" value=\""+inexed.getDate()+"\" id=\"date\" class=\"form-control\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Hour:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"hour\" value=\""+inexed.getHour()+"\" id=\"hour\" class=\"form-control\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Telefon:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"phone\" value=\""+inexed.getPhone()+"\" id=\"phone\" class=\"form-control\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Shoosed style:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"subject\" value=\""+getStyleselecteted()+"\" id=\"subject\" class=\"form-control\" style=\"max-width: 500px;\" disabled=\"disabled\" title=\"you can take it from portfolio\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tr>\r\n"
						+ "								        <td><span class=\"field-name\">Message:</span></td>\r\n"
						+ "								        <td><input class=\"field-input\" type=\"text\" name=\"message\" value=\""+inexed.getMessage()+"\" id=\"message\" class=\"form-control\" style=\"max-width: 500px;\"></td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    <tfoot>\r\n"
						+ "								    <tr>\r\n"
						+ "								    <td></td>\r\n"
						+ "								    <td><br>\r\n"
						+ "									<!-- Button zum Bearbeiten des Termins -->\r\n"
						+ "   									 <button class=\"btn btn-primary\" type=\"submit\" name=\"save\" value=\""+inexed.getId()+"\" onclick=\"return confirm('Sind Sie sicher, dass Sie den Termin speichern?')\">Save Appointment</button>\r\n"
						+ "								    <!-- Button zum L�schen des Termins -->\r\n"
						+ "								    <button class=\"btn btn-secondary\" type=\"submit\" name=\"cancel\" value=\""+inexed.getId()+"\" style=\"background-color: red;\" onclick=\"return confirm('Sind Sie sicher, dass Sie den Vorgang Abbrechen m�chten?')\">don't save</button>\r\n"
						+ "									</td>\r\n"
						+ "								    </tr>\r\n"
						+ "								    </tfoot>\r\n"
						+ "								</table>\r\n"
						+ "							</form>";
				return html;
				
			}
			
			String html="<form id=\"contact-form\" class=\"form\" action=\"appointmentAppl.jsp\" method=\"get\">\r\n"
					+ "\r\n"
					+ "<br> <br> <br>\r\n"
					+ "<h1> Hier are you Booked Appointment</h1> <br>";
			if (terminen.size()==0) {
				html+="<br><br><br><h1 style=\"color: red;\"> you have any Appointment for the moment</h1> <br>";
				return html;
				
			}for (Termin termin : terminen) {
				html+="<br> <br> <ul>\r\n"
						+ "	<li><span class=\"field-name\">Name:</span> "+termin.getName()+"</li>\r\n"
						+ "	 <li><span class=\"field-name\">E-Mail:</span> "+termin.getEmailApp()+"</li>\r\n"
						+ "	 <li><span class=\"field-name\">Date:</span>"+termin.getDate()+"</li>\r\n"
						+ "	<li><span class=\"field-name\">Hour:</span> "+termin.getHour()+"</li>\r\n"
						+ "	 <li><span class=\"field-name\">Telefon:</span> "+termin.getPhone()+"</li>\r\n"
						+ "	 <li><span class=\"field-name\">Shoosed style:</span> "+termin.getSubject()+"</li>\r\n"
						+ "	 <li><span class=\"field-name\">Message:</span> "+termin.getMessage()+".</li>\r\n"
						+ "	 </ul>	<br>\r\n"
						+ "	<!-- Button zum Bearbeiten des Termins -->\r\n"
						+ "  <button class=\"btn btn-primary\" type=\"submit\" name=\"modif\" value=\""+termin.getId()+"\" onclick=\"return confirm('Sind Sie sicher, dass Sie den Termin bearbeiten m�chten?')\">Edit Appointment</button>\r\n"
						+ "	 <!-- Button zum L�schen des Termins -->\r\n"
						+ "	 <button class=\"btn btn-secondary\" type=\"submit\" name=\"drop\" value=\""+termin.getId()+"\" style=\"background-color: red;\" onclick=\"return confirm('Sind Sie sicher, dass Sie den Termin l�schen m�chten?')\">Drop Appointment</button>\r\n"
						+ "	";
			}
			html+="</form>";
			return html;
			
		}
		
		
	    public String getFrisurenAsHtml() /*throws SQLException*/ {
	        StringBuilder htmlBuilder = new StringBuilder();
	        try {
	            Connection dbConn = new PostgreSQLAccess().getConnection();
	            

	            String query = "SELECT style, description, preis FROM bwi520_634753.frisurs";
	            PreparedStatement preparedStatement = dbConn.prepareStatement(query);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            htmlBuilder.append("<table style=\"width: 50%;\">");
	           // htmlBuilder.append("<tbody>");

	            while (resultSet.next()) {
	                String style = resultSet.getString("style");
	                String description = resultSet.getString("description");
	                double preis = resultSet.getDouble("preis");

	                htmlBuilder.append("<tr>");
	             //   htmlBuilder.append("<td style=\"width: 100%;\">"); // Set width to 80%
	                htmlBuilder.append("<td><img src=\"assets/img/images/").append(style).append(".jpeg\" alt=\"").append(style).append("\" style=\"width: 600px; height: 400px;\"></td>");
	                htmlBuilder.append("<td><th>Stil:</b> ").append(style).append("<br>");
	                htmlBuilder.append("<b>Beschreibung:</b> ").append(description).append("<br>");
	                htmlBuilder.append("<b>Preis:</b> ").append(preis).append("&euro;");
	                htmlBuilder.append("<br><a href=\"appointmentAppl.jsp?termin=termin&styleselecteted=").append(style).append("\" class=\"btn btn-primary\">Termin nehmen</a>");
	                htmlBuilder.append("</td>");
	                htmlBuilder.append("</tr>");
	            }
	            htmlBuilder.append("</table>");
	            resultSet.close();
	            preparedStatement.close();
	            dbConn.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return htmlBuilder.toString();
	    }
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the emailApp
		 */
		public String getEmailApp() {
			return emailApp;
		}
		/**
		 * @param emailApp the emailApp to set
		 */
		public void setEmailApp(String emailApp) {
			this.emailApp = emailApp;
		}
		/**
		 * @return the date
		 */
		public String getDate() {
			return date;
		}
		/**
		 * @param date the date to set
		 */
		public void setDate(String date) {
			this.date = date;
		}
		/**
		 * @return the person
		 */
		public String getHour() {
			return hour;
		}
		/**
		 * @param person the person to set
		 */
		public void setHour(String hour) {
			this.hour = hour;
		}
		/**
		 * @return the phone
		 */
		public String getPhone() {
			return phone;
		}
		/**
		 * @param phone the phone to set
		 */
		public void setPhone(String phone) {
			this.phone = phone;
		}
		/**
		 * @return the subject
		 */
		public String getSubject() {
			
			return subject;
		}
		/**
		 * @param subject the subject to set
		 */
		public void setSubject(String subject) {
			this.subject = subject;
		}
		/**
		 * @return the message
		 */
		public String getMessage() {
			return message;
		}
		/**
		 * @param message the message to set
		 */
		public void setMessage(String message) {
			this.message = message;
		}
		/**
		 * @return the email
		 */
		public String getEmail() {
			return email;
		}
		/**
		 * @param email the email to set
		 */
		public void setEmail(String email) {
			this.email = email;
		}
		/**
		 * @return the id
		 */
		public int getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(int id) {
			this.id = id;
		}
		/**
		 * @return the admin
		 */
		public boolean isAdmin() {
			return admin;
		}
		/**
		 * @return the modif
		 */
		public boolean isModif() {
			return modif;
		}
		/**
		 * @param modif the modif to set
		 */
		public void setModif(boolean modif) {
			this.modif = modif;
		}
		/**
		 * @param admin the admin to set
		 */
		public void setAdmin(boolean admin) {
			this.admin = admin;
		}
}